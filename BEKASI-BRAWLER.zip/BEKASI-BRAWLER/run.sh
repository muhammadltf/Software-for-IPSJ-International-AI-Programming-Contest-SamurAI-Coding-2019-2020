#!/bin/sh
./bekasiBrawler