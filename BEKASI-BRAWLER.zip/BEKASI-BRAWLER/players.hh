#include "fieldMap.hh"

extern int planSamurai(GameInfo &info);
extern int planDog(GameInfo &info);
